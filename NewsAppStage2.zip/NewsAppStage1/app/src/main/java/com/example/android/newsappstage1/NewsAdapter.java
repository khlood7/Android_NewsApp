package com.example.android.newsappstage1;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

/**
 * Created by khlood on 23/05/18.
 */
public class NewsAdapter extends ArrayAdapter<News> {

    public NewsAdapter(Activity context, ArrayList<News> news) {

        super(context, 0, news);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }
        News currentNews = getItem(position);

        TextView title = (TextView) convertView.findViewById(R.id.title);
        title.setText(currentNews.getTitle());

        TextView author = (TextView) convertView.findViewById(R.id.author);
        author.setText(currentNews.getAuthor());

        TextView dateView = (TextView) convertView.findViewById(R.id.date);
        dateView.setText(currentNews.getDate());

        TextView section = (TextView) convertView.findViewById(R.id.section);
        section.setText(currentNews.getSection());

        return convertView;
    }
}